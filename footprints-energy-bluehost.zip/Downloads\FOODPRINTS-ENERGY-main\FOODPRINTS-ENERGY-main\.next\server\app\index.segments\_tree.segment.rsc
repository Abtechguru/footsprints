:HL["/_next/static/chunks/0e2lcuesuvi0v.css","style"]
:HL["https://api.fontshare.com/v2/css?f[]=general-sans@200,300,400,500,600,700&display=swap","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}},"staleTime":300,"buildId":"UMlnopm-kLxCsbbYeUJiF"}
