var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_0sqmaqd._.js")
R.c("server/chunks/[root-of-the-server]__0l3l-~x._.js")
R.c("server/chunks/0241_ODPRINTS-ENERGY-main__next-internal_server_app_favicon_ico_route_actions_0wbyvz~.js")
R.m(55546)
module.exports=R.m(55546).exports
