module.exports=[66979,(a,b,c)=>{}];

//# sourceMappingURL=0ub9__next-internal_server_app__global-error_page_actions_0iifbcb.js.map