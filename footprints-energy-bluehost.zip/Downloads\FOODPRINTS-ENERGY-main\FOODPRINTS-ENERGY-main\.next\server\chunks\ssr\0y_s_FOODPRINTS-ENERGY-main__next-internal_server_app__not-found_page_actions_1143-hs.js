module.exports=[54837,(a,b,c)=>{}];

//# sourceMappingURL=0y_s_FOODPRINTS-ENERGY-main__next-internal_server_app__not-found_page_actions_1143-hs.js.map