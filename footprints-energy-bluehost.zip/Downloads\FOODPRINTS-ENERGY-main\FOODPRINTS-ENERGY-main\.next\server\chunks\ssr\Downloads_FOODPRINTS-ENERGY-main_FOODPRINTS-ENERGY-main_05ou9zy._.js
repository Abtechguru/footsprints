module.exports=[98851,a=>{"use strict";var b=a.i(88015);a.s([],28461),a.i(28461),a.s(["408818b3c1a55dd6643193a3b8574b0bff4230dcb6",()=>b.subscribeNewsletter],98851)},92747,a=>{a.v(b=>Promise.all(["server/chunks/ssr/11tj_0~.7qce._.js"].map(b=>a.l(b))).then(()=>b(55455)))}];

//# sourceMappingURL=Downloads_FOODPRINTS-ENERGY-main_FOODPRINTS-ENERGY-main_05ou9zy._.js.map