module.exports=[86281,(e,o,d)=>{}];

//# sourceMappingURL=0241_ODPRINTS-ENERGY-main__next-internal_server_app_favicon_ico_route_actions_0wbyvz~.js.map