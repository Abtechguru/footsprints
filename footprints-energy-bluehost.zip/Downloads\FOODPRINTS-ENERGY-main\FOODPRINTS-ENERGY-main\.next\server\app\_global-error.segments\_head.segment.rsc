1:"$Sreact.fragment"
2:I[31005,["/_next/static/chunks/0ow12_y9dz08h.js","/_next/static/chunks/0z-z4qwptlr3k.js"],"ViewportBoundary"]
3:I[31005,["/_next/static/chunks/0ow12_y9dz08h.js","/_next/static/chunks/0z-z4qwptlr3k.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[70639,["/_next/static/chunks/0ow12_y9dz08h.js","/_next/static/chunks/0z-z4qwptlr3k.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","link","0",{"rel":"icon","href":"/favicon.ico?favicon.0x3dzn~oxb6tn.ico","sizes":"256x256","type":"image/x-icon"}],["$","$L5","1",{}]]}]}]}],null]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"zkcY1S-6EXlEt5NZiw6CU"}
