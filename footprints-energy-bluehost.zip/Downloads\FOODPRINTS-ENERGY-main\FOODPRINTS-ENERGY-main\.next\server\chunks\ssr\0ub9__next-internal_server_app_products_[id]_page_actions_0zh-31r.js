module.exports=[70815,(a,b,c)=>{}];

//# sourceMappingURL=0ub9__next-internal_server_app_products_%5Bid%5D_page_actions_0zh-31r.js.map