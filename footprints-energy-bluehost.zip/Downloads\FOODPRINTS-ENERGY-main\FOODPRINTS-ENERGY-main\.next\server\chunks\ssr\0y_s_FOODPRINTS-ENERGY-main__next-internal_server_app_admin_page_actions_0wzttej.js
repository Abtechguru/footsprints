module.exports=[37833,(a,b,c)=>{}];

//# sourceMappingURL=0y_s_FOODPRINTS-ENERGY-main__next-internal_server_app_admin_page_actions_0wzttej.js.map