module.exports=[21165,(a,b,c)=>{}];

//# sourceMappingURL=0ub9__next-internal_server_app_admin_invoices_page_actions_0zlferv.js.map