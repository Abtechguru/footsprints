module.exports=[78869,a=>{"use strict";var b=a.i(35823);let c="https://jxaabueppbpukhtfguqx.supabase.co",d=(0,b.createClient)(c,"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp4YWFidWVwcGJwdWtodGZndXF4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzkxMjEzNzgsImV4cCI6MjA5NDY5NzM3OH0.N1tOApR1yZWaSEAtUy8W1t7NXqmIYzmN0xMyWqzJl7Q"),e=(0,b.createClient)(c,process.env.SUPABASE_SERVICE_ROLE_KEY,{auth:{autoRefreshToken:!1,persistSession:!1}});a.s(["supabase",0,d,"supabaseAdmin",0,e])},71628,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"InvariantError",{enumerable:!0,get:function(){return d}});class d extends Error{constructor(a,b){super(`Invariant: ${a.endsWith(".")?a:a+"."} This is a bug in Next.js.`,b),this.name="InvariantError"}}},45422,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0});var d={RequestCookies:function(){return f.RequestCookies},ResponseCookies:function(){return f.ResponseCookies},stringifyCookie:function(){return f.stringifyCookie}};for(var e in d)Object.defineProperty(c,e,{enumerable:!0,get:d[e]});let f=a.r(50757)},24119,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0});var d={ActionDidNotRevalidate:function(){return f},ActionDidRevalidateDynamicOnly:function(){return h},ActionDidRevalidateStaticAndDynamic:function(){return g}};for(var e in d)Object.defineProperty(c,e,{enumerable:!0,get:d[e]});let f=0,g=1,h=2},98088,(a,b,c)=>{"use strict";Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"registerServerReference",{enumerable:!0,get:function(){return d.registerServerReference}});let d=a.r(31358)},40696,(a,b,c)=>{"use strict";function d(a){for(let b=0;b<a.length;b++){let c=a[b];if("function"!=typeof c)throw Object.defineProperty(Error(`A "use server" file can only export async functions, found ${typeof c}.
Read more: https://nextjs.org/docs/messages/invalid-use-server-value`),"__NEXT_ERROR_CODE",{value:"E352",enumerable:!1,configurable:!0})}}Object.defineProperty(c,"__esModule",{value:!0}),Object.defineProperty(c,"ensureServerEntryExports",{enumerable:!0,get:function(){return d}})},88015,a=>{"use strict";var b=a.i(98088),c=a.i(78869),d=a.i(27099);async function e(a){let b=a.get("name"),e=a.get("category"),f=a.get("imageFile"),g=a.get("size");if(!b||!e||!f||!g)return;let h="";if(f&&f.size>0){let a=f.name.split(".").pop(),b=`${Date.now()}-${Math.random().toString(36).substring(7)}.${a}`,{error:d}=await c.supabaseAdmin.storage.from("images").upload(b,f,{contentType:f.type});if(d)return void console.error(d);let{data:e}=c.supabaseAdmin.storage.from("images").getPublicUrl(b);h=e.publicUrl}let{error:i}=await c.supabaseAdmin.from("products").insert([{name:b,category:e,image:h,size:g}]);i?console.error(i):((0,d.revalidatePath)("/"),(0,d.revalidatePath)("/admin/products"))}async function f(a){let{error:b}=await c.supabaseAdmin.from("products").delete().eq("id",a);b?console.error(b):((0,d.revalidatePath)("/"),(0,d.revalidatePath)("/admin/products"))}async function g(a){let b=a.get("name"),e=a.get("role"),f=a.get("imageFile");if(!b||!e||!f)return;let g="";if(f&&f.size>0){let a=f.name.split(".").pop(),b=`${Date.now()}-${Math.random().toString(36).substring(7)}.${a}`,{error:d}=await c.supabaseAdmin.storage.from("images").upload(b,f,{contentType:f.type});if(d)return void console.error(d);let{data:e}=c.supabaseAdmin.storage.from("images").getPublicUrl(b);g=e.publicUrl}let{error:h}=await c.supabaseAdmin.from("team_members").insert([{name:b,role:e,image:g}]);h?console.error(h):((0,d.revalidatePath)("/"),(0,d.revalidatePath)("/admin/team"))}async function h(a){let{error:b}=await c.supabaseAdmin.from("team_members").delete().eq("id",a);b?console.error(b):((0,d.revalidatePath)("/"),(0,d.revalidatePath)("/admin/team"))}async function i(a){let b=a.get("email");if(!b)return{success:!1,error:"Email is required"};let{error:d}=await c.supabaseAdmin.from("subscribers").insert([{email:b}]);return d?(console.error(d),"23505"===d.code)?{success:!1,error:"You are already subscribed!"}:{success:!1,error:"Subscription failed. Please try again."}:{success:!0}}async function j(b){let d=b.get("subject"),e=b.get("content");if(!d||!e)return{success:!1,error:"Subject and content are required."};let{data:f,error:g}=await c.supabaseAdmin.from("subscribers").select("email");if(g||!f||0===f.length)return{success:!1,error:"No subscribers found or failed to fetch."};let h=f.map(a=>a.email),i=process.env.RESEND_API_KEY;if(!i)return{success:!1,error:"RESEND_API_KEY is not configured in your environment variables. Please add it to your .env.local file to send live emails."};try{let{Resend:b}=await a.A(92747),c=new b(i),{error:f}=await c.emails.send({from:"Footprints Energy <newsletter@footprints-energy.com>",to:"newsletter@footprints-energy.com",bcc:h,subject:d,html:`
        <div style="font-family: sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #1d1d1d/5; rounded: 8px;">
          <h2 style="color: #FD630A; font-weight: bold; margin-bottom: 20px;">Footprints Energy Newsletter</h2>
          <div style="font-size: 16px; line-height: 1.6; color: #1d1d1d;">
            ${e.replace(/\n/g,"<br />")}
          </div>
          <hr style="border: 0; border-top: 1px solid #eee; margin: 30px 0;" />
          <p style="font-size: 12px; color: #666; text-align: center;">
            You are receiving this because you subscribed to Footprints Energy updates.<br />
            To unsubscribe, please contact us.
          </p>
        </div>
      `});if(f)return console.error(f),{success:!1,error:f.message};return{success:!0}}catch(a){return console.error(a),{success:!1,error:a.message||"An unexpected error occurred."}}}async function k(b){let{buyerEmail:c,buyerName:d,receiptNo:e,date:f,items:g,payments:h,totalCharges:i,footnotes:j}=b;if(!c)return{success:!1,error:"Buyer's email is required."};let k=process.env.RESEND_API_KEY;if(!k)return{success:!1,error:"RESEND_API_KEY is not configured in your environment variables. Please add it to your .env.local file to send live emails."};let l=g.map(a=>`
    <tr style="border-bottom: 1px solid #ddd;">
      <td style="padding: 10px; font-size: 13px;">${a.date}</td>
      <td style="padding: 10px; font-size: 13px;">${a.type}</td>
      <td style="padding: 10px; font-size: 13px;">${a.productType}</td>
      <td style="padding: 10px; font-size: 13px; font-weight: bold;">${a.productName}</td>
      <td style="padding: 10px; font-size: 13px;">${a.term}</td>
      <td style="padding: 10px; font-size: 13px; text-align: right;">USD${a.amount.toFixed(2)}</td>
      <td style="padding: 10px; font-size: 13px; text-align: right;">USD${a.tax.toFixed(2)}</td>
      <td style="padding: 10px; font-size: 13px;">${a.taxType}</td>
      <td style="padding: 10px; font-size: 13px; text-align: right; font-weight: bold;">USD${a.total.toFixed(2)}</td>
    </tr>
  `).join(""),m=h.map(a=>`
    <tr style="border-bottom: 1px solid #ddd;">
      <td style="padding: 10px; font-size: 13px;">${a.date}</td>
      <td style="padding: 10px; font-size: 13px;">${a.orderNo}</td>
      <td style="padding: 10px; font-size: 13px; font-weight: bold;">${a.method}</td>
      <td style="padding: 10px; font-size: 13px;">${a.details}</td>
      <td style="padding: 10px; font-size: 13px; text-align: right; font-weight: bold;">USD${a.total.toFixed(2)}</td>
    </tr>
  `).join("");try{let{Resend:b}=await a.A(92747),g=new b(k),{error:h}=await g.emails.send({from:"FootprintsEnergy <receipts@footprints-energy.com>",to:c,subject:`Receipt for Order #${e} - FootprintsEnergy`,html:`
        <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 30px; border: 1px solid #eee; border-radius: 8px; color: #1D1D1D;">
          <!-- Header -->
          <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #FD630A; padding-bottom: 20px; margin-bottom: 30px;">
            <div>
              <h1 style="color: #1D1D1D; font-size: 28px; font-weight: 800; margin: 0;">Footprints<span style="color: #FD630A;">Energy</span></h1>
              <p style="font-size: 12px; color: #666; margin: 5px 0 0 0;">Global Commodity & Energy Trade Partner</p>
            </div>
            <div style="text-align: right;">
              <h2 style="font-size: 20px; font-weight: 700; color: #666; margin: 0;">RECEIPT</h2>
              <p style="font-size: 12px; margin: 5px 0 0 0;"><strong>No:</strong> ${e}</p>
              <p style="font-size: 12px; margin: 2px 0 0 0;"><strong>Date:</strong> ${f}</p>
            </div>
          </div>

          <!-- Recipient -->
          <div style="margin-bottom: 30px; background-color: #F7F3E6; padding: 15px; border-radius: 6px;">
            <h3 style="font-size: 14px; text-transform: uppercase; color: #FD630A; margin: 0 0 8px 0; font-weight: bold; letter-spacing: 0.05em;">Billed To</h3>
            <p style="font-size: 14px; font-weight: bold; margin: 0;">${d}</p>
            <p style="font-size: 13px; color: #555; margin: 4px 0 0 0;">${c}</p>
          </div>

          <!-- Charges and Credits Table -->
          <h3 style="font-size: 16px; font-weight: bold; margin: 0 0 10px 0; color: #1D1D1D;">Charges and Credits:</h3>
          <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px; text-align: left;">
            <thead>
              <tr style="background-color: #7f7f7f; color: #ffffff;">
                <th style="padding: 10px; font-size: 12px; text-transform: uppercase;">Date</th>
                <th style="padding: 10px; font-size: 12px; text-transform: uppercase;">Type</th>
                <th style="padding: 10px; font-size: 12px; text-transform: uppercase;">Product Type</th>
                <th style="padding: 10px; font-size: 12px; text-transform: uppercase;">Product Name</th>
                <th style="padding: 10px; font-size: 12px; text-transform: uppercase;">Term</th>
                <th style="padding: 10px; font-size: 12px; text-transform: uppercase; text-align: right;">Amount</th>
                <th style="padding: 10px; font-size: 12px; text-transform: uppercase; text-align: right;">Tax</th>
                <th style="padding: 10px; font-size: 12px; text-transform: uppercase;">Tax Type</th>
                <th style="padding: 10px; font-size: 12px; text-transform: uppercase; text-align: right;">Total Charges</th>
              </tr>
            </thead>
            <tbody>
              ${l}
              <!-- Subtotals -->
              <tr style="border-top: 2px solid #ddd; background-color: #f9f9f9;">
                <td colspan="7" style="padding: 10px; font-size: 13px; font-weight: bold; text-align: right;">Total Invoice Amount</td>
                <td colspan="2" style="padding: 10px; font-size: 14px; font-weight: bold; text-align: right; color: #FD630A;">USD${i.toFixed(2)}</td>
              </tr>
            </tbody>
          </table>

          <!-- Payments Table -->
          <h3 style="font-size: 16px; font-weight: bold; margin: 30px 0 10px 0; color: #1D1D1D;">Payments:</h3>
          <table style="width: 100%; border-collapse: collapse; margin-bottom: 30px; text-align: left;">
            <thead>
              <tr style="background-color: #7f7f7f; color: #ffffff;">
                <th style="padding: 10px; font-size: 12px; text-transform: uppercase;">Date</th>
                <th style="padding: 10px; font-size: 12px; text-transform: uppercase;">Order Number</th>
                <th style="padding: 10px; font-size: 12px; text-transform: uppercase;">Payment Method</th>
                <th style="padding: 10px; font-size: 12px; text-transform: uppercase;">Check/Card#/PayPal ID</th>
                <th style="padding: 10px; font-size: 12px; text-transform: uppercase; text-align: right;">Total Payments</th>
              </tr>
            </thead>
            <tbody>
              ${m}
            </tbody>
          </table>

          <!-- Footnotes -->
          <div style="border-top: 1px dashed #ddd; padding-top: 20px;">
            <h4 style="font-size: 12px; text-transform: uppercase; color: #666; margin: 0 0 8px 0;">Please Note:</h4>
            <p style="font-size: 11px; color: #777; line-height: 1.5; margin: 0;">
              ${j.replace(/\n/g,"<br />")}
            </p>
          </div>
        </div>
      `});if(h)return console.error(h),{success:!1,error:h.message};return{success:!0}}catch(a){return console.error(a),{success:!1,error:a.message||"An unexpected error occurred."}}}async function l(a){let{receiptNo:b,buyerName:e,buyerEmail:f,date:g,items:h,payments:i,totalCharges:j,footnotes:k}=a,{data:l,error:m}=await c.supabaseAdmin.from("receipts").insert([{receipt_no:b,buyer_name:e,buyer_email:f,date:g,items:h,payments:i,total_charges:j,footnotes:k}]).select();if(m){if(console.error(m),"23505"===m.code){let{data:a,error:l}=await c.supabaseAdmin.from("receipts").update({buyer_name:e,buyer_email:f,date:g,items:h,payments:i,total_charges:j,footnotes:k}).eq("receipt_no",b).select();return l?(console.error(l),{success:!1,error:l.message}):((0,d.revalidatePath)("/admin/receipts"),{success:!0,receipt:a[0]})}return{success:!1,error:m.message}}return(0,d.revalidatePath)("/admin/receipts"),{success:!0,receipt:l[0]}}async function m(a){let{error:b}=await c.supabaseAdmin.from("receipts").delete().eq("id",a);return b?(console.error(b),{success:!1,error:b.message}):((0,d.revalidatePath)("/admin/receipts"),{success:!0})}(0,a.i(40696).ensureServerEntryExports)([e,f,g,h,i,j,k,l,m]),(0,b.registerServerReference)(e,"4025352ec3b29b053108e240bef9c0dcc5a6c59887",null),(0,b.registerServerReference)(f,"40d5ef1e8efdc96e22a8c564f35ca71b82758f507a",null),(0,b.registerServerReference)(g,"40bb2f473814381d9dd4a0c357bde581b5d216e5c5",null),(0,b.registerServerReference)(h,"405be8134f5169dd6e7a174b77444e87749bc86377",null),(0,b.registerServerReference)(i,"408818b3c1a55dd6643193a3b8574b0bff4230dcb6",null),(0,b.registerServerReference)(j,"4054069a68319b8f3f3fb43b89664c77a666bf9673",null),(0,b.registerServerReference)(k,"405cec5665222841ab2acfe674000b3f47201deda9",null),(0,b.registerServerReference)(l,"40c63713ff9a11911062cbf1ce2b5044dc36c41314",null),(0,b.registerServerReference)(m,"405c6f50105b28c9ee1374944316d3ecbd8fddde79",null),a.s(["addProduct",0,e,"addTeamMember",0,g,"deleteProduct",0,f,"deleteReceipt",0,m,"deleteTeamMember",0,h,"saveReceipt",0,l,"sendNewsletter",0,j,"sendReceiptEmail",0,k,"subscribeNewsletter",0,i])},15669,a=>{"use strict";var b=a.i(88015);a.s([],64211),a.i(64211),a.s(["408818b3c1a55dd6643193a3b8574b0bff4230dcb6",()=>b.subscribeNewsletter],15669)},92747,a=>{a.v(b=>Promise.all(["server/chunks/ssr/11tj_0~.7qce._.js"].map(b=>a.l(b))).then(()=>b(55455)))}];

//# sourceMappingURL=Downloads_FOODPRINTS-ENERGY-main_FOODPRINTS-ENERGY-main_0~f6uun._.js.map