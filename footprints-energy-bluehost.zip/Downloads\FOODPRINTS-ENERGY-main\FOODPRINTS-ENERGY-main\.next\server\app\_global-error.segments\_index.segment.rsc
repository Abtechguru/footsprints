1:"$Sreact.fragment"
2:I[99991,["/_next/static/chunks/0ow12_y9dz08h.js","/_next/static/chunks/0z-z4qwptlr3k.js"],"default"]
3:I[56728,["/_next/static/chunks/0ow12_y9dz08h.js","/_next/static/chunks/0z-z4qwptlr3k.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"zkcY1S-6EXlEt5NZiw6CU"}
