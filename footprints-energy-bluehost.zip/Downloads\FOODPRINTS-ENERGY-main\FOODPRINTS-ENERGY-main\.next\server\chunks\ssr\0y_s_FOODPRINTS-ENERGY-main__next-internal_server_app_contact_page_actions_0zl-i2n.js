module.exports=[48156,(a,b,c)=>{}];

//# sourceMappingURL=0y_s_FOODPRINTS-ENERGY-main__next-internal_server_app_contact_page_actions_0zl-i2n.js.map