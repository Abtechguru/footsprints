globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/zkcY1S-6EXlEt5NZiw6CU/_buildManifest.js",
    "static/zkcY1S-6EXlEt5NZiw6CU/_ssgManifest.js",
    "static/zkcY1S-6EXlEt5NZiw6CU/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ja3eb~y73~17.js",
    "static/chunks/003p4f8ltdzu0.js",
    "static/chunks/0x53ahq1m1gnw.js",
    "static/chunks/0q8m6cx3jz70w.js",
    "static/chunks/07v-mslrs6hqo.js",
    "static/chunks/turbopack-0gm7~lj-u4l1i.js"
  ]
};
